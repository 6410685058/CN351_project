<!-- 6410685124 Tanakrit Iewwangso -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>form</title>
</head>

<body>
    <form action="formhandler.php" method="post">

        <label for="name">Fist name: </label>
        <input type="text" name="name" id="name" size="20" maxlength="30" value="Somsak">
        <br>

        <label for="surname">Last name: </label>
        <input type="text" name="surname" id="surname" size="20" maxlength="30" required>
        <br>

        <label for="password">Password: </label>
        <input type="password" id="password" name="password">
        <br>

        Gender:<br>
        <input type="radio" id="male" name="gender" value="male">
        <label for="male">Male</label>

        <input type="radio" id="female" name="gender" value="female">
        <label for="female">Female</label>
        <br>

        Receive nawsletter:<br>
        <input type="checkbox" name="receive[]" id="newsLetter" value="paper">
        <label for="c1">Paper newsletter</label>

        <input type="checkbox" name="receive[]" id="email" value="email">
        <label for="email">Email newsletter</label>
        <br>

        Your car:<br>
        <select name="car[]" size="4" multiple>
            <option value="volvo">Volvo</option>
            <option value="saab" selected>Saab</option>
            <option value="mg">MG</option>
            <option value="tesla" selected>Tesla</option>
        </select><br>

        <textarea name="address" cols="30" rows="4"></textarea><br>

        <input type="hidden" name="subject" value="cn334"><br>

        <input type="submit">
        <input type="reset">


    </form>
</body>
</html>
