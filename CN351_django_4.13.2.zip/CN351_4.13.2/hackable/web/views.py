from django.shortcuts import render, redirect
# for login
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
# Create your views here.

# base page
def index(request) :
    return render(request, 'base.html')

# login
def login(request) :
    message = ""
    # if user filled the form
    if(request.method == "POST") :
        # get user's input
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        # check if username & password match with an existed account
        user = authenticate(request, username=username, password=password)

        # if matched
        if user is not None :
            # log user into this account
            auth_login(request, user)
            return redirect('view_user')
        else :
            message = "Wrong Username or Password"
    data = {
        "message" : message
    }
    return render(request, 'login.html', data)

# logout
def logout(request) :
    auth_logout(request)
    return redirect('login')

# view all existed users
def view_user(request) :
    # get all users
    data = {
        'users' : User.objects.all()
    }
    return render(request, 'view_user.html', data)

# view profile
def profile(request) :
    # check if user is allowed to see this page
    username_query = request.GET.get("username")
    username_user = request.user.username

    # if not allowed
    if(username_query != username_user):
        return render(request, 'unauthorized.html')

    data = {
        'user' : request.user
    }
    return render(request, 'profile.html', data)

# page for changing password
def change_password(request) :
    # check if user is allowed to see this page
    username_query = request.GET.get("username")
    username_user = request.user.username

    # if not allowed
    if(username_query != username_user):
        return render(request, 'unauthorized.html')

    message = ""
    if(request.method == "POST") :
        username = request.user.username
        # get user's input
        password_old = request.POST.get('password_old')
        password_new_1 = request.POST.get('password_new_1')
        password_new_2 = request.POST.get('password_new_2')

        # test to see if this is the current password
        test_user = authenticate(username=username, password=password_old)

        # if password matched
        if(test_user is not None and password_new_1 == password_new_2) :
            url = "/confirm_change?username=" + username + "&password=" + password_new_1 + "&change=False"
            return redirect(url)
        else:
            message = "Wrong Inputs"

    data = {
        'message' : message,
        'username' : username_user
    }

    return render(request, 'change_password.html', data)

# confirm changing password (assume User can only come here through the "change_password" page)
def confirm_change(request) :
    # get query parameters
    username = request.GET.get('username')
    password = request.GET.get('password')
    change = request.GET.get('change')

    if(change == "False"):
        # enter this page for the first time
        data = {
            'username' : username,
            'password' : password
        }
        return render(request, 'confirm_change.html', data)
    else:
        # after pressing "yes"
        user_target = User.objects.get(username=username)
        user_target.set_password(password)
        user_target.save()
        auth_login(request, user_target)
        url = "/profile?username=" + username
        return redirect(url)
