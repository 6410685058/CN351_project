<!-- 6410685124 Tanakrit Iewwangso -->
<?php
require_once 'db_model.php';

if ( isset($_POST['insert'] )) {
    $name = $_POST['name'] ?? '';
    $surname = $_POST['surname'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';

    if (insert_data_secure($name, $surname, $email, $phone)) {
        $message = 'Data inserted successfully';
    }else {
        $message = 'Error inserting data';
    }
}elseif ( isset($_POST['update'] )) {

    $id = $_POST['id'] ?? '';
    $name = $_POST['name'] ?? '';
    $surname = $_POST['surname'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    if (update_data($id ,$name, $surname, $email, $phone)) {
        $message = 'Data updated successfully';
    }else {
        $message = 'Error updating data';
    }
}elseif ( isset($_POST['delete']) ) {
    $id = $_POST['id'] ?? '';
    if (delete_data($id)) {
        $message = 'Data deleted successfully';
    }else {
        $message = 'Error deleting data';
    }
}

if ( isset($_GET['update'])) {
    $id = base64_decode($_GET['update']);
    $person = get_data($id);
    require_once 'update_form.php';
}elseif (isset($_GET['delete'])) {
    $id = base64_decode($_GET['update']);
    $person = get_data($id);
    require_once 'delete_form.php';

}elseif (isset($_POST['login']))
{
    $name = $_POST['name'] ?? ''; // หรือคุณอาจจะใช้ชื่อของฟิลด์ที่เก็บ username หรือ email ขึ้นอยู่กับการออกแบบฐานข้อมูล
    // เรียกใช้ฟังก์ชัน login_data เพื่อตรวจสอบชื่อในฐานข้อมูล
    $person = login_data($name);

    // ตรวจสอบว่าพบข้อมูลหรือไม่
    if ($person) {
        // ถ้าพบข้อมูล คุณสามารถดำเนินการต่อได้ เช่น ตรวจสอบรหัสผ่าน หรือเปิด session สำหรับผู้ใช้
        // ตัวอย่าง:
        //$password = $_POST['password'] ?? '';
        //if ($person['password'] === $password) {
        //    session_start();
        //    $_SESSION['user_id'] = $person['id'];
        //    $_SESSION['username'] = $person['username'];
        //    // Redirect to dashboard or any authenticated page
        //    header('Location: dashboard.php');
        //    exit();
        //} else {
        //    $message = 'Incorrect password';
        //}

        // ในที่นี้เราจะแสดงข้อมูลบุคคลเพื่อตรวจสอบเท่านั้น
        // คุณสามารถปรับปรุงโค้ดเพื่อให้ทำงานตามการตรวจสอบรหัสผ่านของคุณได้
        require_once 'data.login.php'; // แสดงฟอร์มเข้าสู่ระบบ
    } else {
        // ถ้าไม่พบข้อมูล
        $message = 'User not found';
        require_once 'login_form.php'; // แสดงฟอร์มเข้าสู่ระบบอีกครั้ง
    }
}else {
    if (isset($_POST['search'])) {
        $name = $_POST['name'] ?? '';
        $surname = $_POST['surname'] ?? '';
        if (empty($name) && empty($surname)) {
            $message = 'Please fill Name or Surname';
            $persons = search_data("--", "--");
            //$persons = get_all_data();
        }else {
            if (!$surname) {
                $name =  "%".$name."%";
                $persons = search_data($name, $surname);

            }elseif (!$name) {
                echo "2<br>";
                $name =  "%".$name."%";
                echo "$name<br>";
                echo "$surname<br>";
                $surname = "%".$surname."%";
                $persons = search_data($name, $surname);
            }else {
                $name =  "%".$name."%";
                $surname = "%".$surname."%";
                $persons = search_data($name, $surname);
            }
            if (!$persons) {
                $message = 'No data in database.';
                $persons = search_data("--", "--");
            }
        }
    }else {
        /*$name = $_POST['name'] ?? '';
        $surname = $_POST['surname'] ?? '';

        $persons = search_data("--", "--");*/
        $persons = search_data("--", "--");
//        var_dump($persons);
    }
    require_once 'data.view.php';
}

?>