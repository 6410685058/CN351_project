<!-- 6410685124 Tanakrit Iewwangso -->
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Person</title>
    <style>
        table, tr, th, td {
            border: 1px solid black;
            border-collapse: collapse;
            padding: .5em;
            margin: auto;
        }

        .text-center {
            text-align: center;
        }
    </style>
</head>
<body>
<h1 class="text-center">Persons Table</h1>

<?php
if (isset($message))
    echo "<p class=\"text-center\">$message</p>"
?>
<p class="text-center">

    <!--<a href="person_form.php">Add new person</a> |-->
    <a href="search_form.php">Search person</a> |
    <a href="person2.php">Logout</a>
</p>

<table>
    <tr>
        <th>ID</th>
        <th>Full name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Update</th>
        <th>Delete</th>
    </tr>

        <tr>
            <td><?= $person['id']?> </td>
            <td><?=$person['name']?> <?= $person['surname']?> </td>
            <td><?= $person['email']?> </td>
            <td><?= $person['phone']?> </td>
            <td><a href="person2.php?update=<?=base64_encode($person['id'])?>">Update</a></td>
            <td><a href="person2.php?delete=<?=base64_encode($person['id'])?>">Delete</a></td>
        </tr>
</table>
</body>
</html>
