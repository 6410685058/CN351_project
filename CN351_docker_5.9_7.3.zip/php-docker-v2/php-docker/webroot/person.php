<!-- 6410685124 Tanakrit Iewwangso -->
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Person</title>
    <style>
        table, tr, th, td {
            border: 1px solid black;
            border-collapse: collapse;
            padding: .5em;
        }
    </style>
</head>
<body>
<?php
require 'data.inc.php';
echo "<table>\n";
echo "<thead>\n";
echo "<tr>\n";
echo "<th>ID</th>\n";
echo "<th>Full name</th>\n";
echo "<th>Email</th>\n";
echo "<th>Phone</th>\n";
echo "</tr>\n";
echo "</thead>\n";
echo "<tbody>\n";
foreach ($persons as $person ) {
    echo "<tr>\n";
    echo "<td>" . $person['id'] . "</td>\n";
    echo "<td>" . $person['name'] . " " . $person['surname'] . "</td>\n";
    echo "<td>" . $person['email'] . "</td>\n";
    echo "<td>" . $person['phone'] . "</td>\n";
    echo "</tr>\n";
}
echo "</tbody>\n";
echo "<tfoot>\n";
echo "</tfoot>\n";
echo "</table>";
?>
</body>
</html>
