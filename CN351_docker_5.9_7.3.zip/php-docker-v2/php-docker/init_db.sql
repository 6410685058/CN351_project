CREATE DATABASE IF NOT EXISTS my_db;

USE my_db;

CREATE TABLE IF NOT EXISTS persons (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) UNIQUE,
  name VARCHAR(100),
  surname VARCHAR(100),
  email VARCHAR(100),
  phone VARCHAR(100)
);

LOAD DATA INFILE '/docker-entrypoint-initdb.d/data.csv'
INTO TABLE persons
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(id, username, name, surname, email, phone);
