<!-- 6410685124 Tanakrit Iewwangso -->
<!doctype html>
<!-- update_form.php -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h1>Search</h1>
<form action="person2.php" method="post">
    <label for="name">Name: </label>
    <input type="text" name="name" id="name"><br>
    <label for="surname">Surname: </label>
    <input type="text" name="surname" id="surname"><br>
    <input type="hidden" name="search" value="1">

    <input type="submit" value="search">
    <input type="button" value="cancel" onclick="history.back()">
</form>
</body>
</html>
