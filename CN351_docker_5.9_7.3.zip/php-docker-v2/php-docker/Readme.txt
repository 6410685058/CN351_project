

phpMyAdmin 

	URL: localhost:8002
	username: root
	password: secret

web-app 

	URL : localhost:8001/person2.php
	login username : test1





