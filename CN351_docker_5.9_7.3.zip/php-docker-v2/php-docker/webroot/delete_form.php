<!-- 6410685124 Tanakrit Iewwangso -->
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Delete person</title>
    <style>
        table, tr, th, td {
            border: 1px solid black;
            border-collapse: collapse;
            padding: .5em;
            margin: auto;
        }

        .text-center {
            text-align: center;
        }
    </style>
</head>
<body>
<h1 class="text-center" style="color: red">Delete Person</h1>
<table>
    <tr>
        <th>ID</th>
        <th>Full name</th>
        <th>Email</th>
        <th>Phone</th>
    </tr>
    <tr>
        <td><?= $person['id']?> </td>
        <td><?=$person['name']?> <?= $person['surname']?> </td>
        <td><?= $person['email']?> </td>
        <td><?= $person['phone']?> </td>
    </tr>
</table>
<form action="person2.php" method="post">
<!--    <label for="name">Name: </label>-->
<!--    <input type="hidden" name="name" id="name" value="--><?php //= $person['name']; ?><!--"><br>-->
<!--    <label for="surname">Surname: </label>-->
<!--    <input type="text" name="surname" id="surname" value="--><?php //= $person['surname']; ?><!--" readonly="readonly"><br>-->
<!--    <label for="email">Email: </label>-->
<!--    <input type="email" name="email" id="email"  value="--><?php //= $person['email']; ?><!--" readonly="readonly"><br>-->
<!--    <label for="phone">Phone: </label>-->
<!--    <input type="tel" name="phone" id="phone" value="--><?php //= $person['phone']; ?><!--" readonly="readonly"><br>-->
    <input type="hidden" name="id" value="<?= $person['id']; ?>">
    <input type="hidden" name="delete" value="1">
    <div style="text-align: center; margin-top: 1em">
        <input type="submit" value="confirm">
        <input type="button" value="cancel" onclick="history.back()">
    </div>

</form>
</body>
</html>
