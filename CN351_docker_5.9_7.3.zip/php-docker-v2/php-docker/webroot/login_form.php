
<!doctype html>
<!-- update_form.php -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h1>Login</h1>
<?php
if (isset($message))
    echo "<p class=\"text-center\">$message</p>"
?>
<form action="person2.php" method="post">
    <label for="name">Username: </label>
    <input type="text" name="name" id="name"><br>
    <input type="hidden" name="login" value="1">

    <input type="submit" value="login">
    <input type="button" value="cancel" onclick="history.back()">
</form>
</body>
</html>
